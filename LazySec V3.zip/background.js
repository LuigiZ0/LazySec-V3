// background.js - Adicionada lógica de persistência

// Listener para tradução (sem alterações)
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getTranslation') {
    try {
      const message = chrome.i18n.getMessage(request.key, request.substitutions || []);
      sendResponse({ message: message });
    } catch (e) {
      console.error(`Erro ao traduzir a chave: ${request.key}`, e);
      sendResponse({ message: `[${request.key}]` });
    }
  }
  return true;
});

// NOVO: Listener para reaplicar alterações em navegações
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  // Garante que a página esteja completamente carregada e seja uma URL válida
  if (changeInfo.status === 'complete' && tab.url?.startsWith('http')) {
    const storageKey = `tab_${tabId}`;
    
    // Verifica se existem configurações salvas para esta aba
    chrome.storage.session.get(storageKey, (data) => {
      const settings = data[storageKey];
      
      // Se encontrarmos configurações, injeta os scripts para reaplicar a ação
      if (settings && settings.actions && settings.options) {
        console.log(`LazySec: Reaplicando alterações na aba ${tabId}`);
        chrome.scripting.executeScript({
          target: { tabId: tabId },
          func: (actions, opts) => {
            window.lazySecActionType = actions;
            Object.assign(window, opts);
          },
          args: [settings.actions, settings.options]
        }).then(() => {
          chrome.scripting.executeScript({
            target: { tabId: tabId },
            files: ['lazysec-script.js']
          });
        }).catch(err => console.error("LazySec: Falha ao injetar script.", err));
      }
    });
  }
});