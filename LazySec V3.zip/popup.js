// popup.js - v26.5 - Lógica final aprimorada: Desfazer também desmarca a persistência

const CHECKBOX_KEYS = ["input_controls", "buttons", "divs", "labels", "all", "persist_changes"];
const STORAGE_KEY = 'lazySecCheckboxState';

let pageState = { isActive: false, activeActionTypes: new Set(), lastUsedOptions: null };
let currentTabId = null;

document.addEventListener("DOMContentLoaded", () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs.length === 0 || !tabs[0].id || !tabs[0].url?.startsWith("http")) {
            document.body.innerHTML = `<div class="error-msg">${chrome.i18n.getMessage('errorPage')}</div>`;
            return;
        }
        currentTabId = tabs[0].id;
        main(currentTabId);
    });
});

async function main(tabId) {
    document.getElementById("unveilButton")?.addEventListener("click", () => executeAction(tabId, ['apply_unveil']));
    document.getElementById("unblockButton")?.addEventListener("click", () => executeAction(tabId, ['apply_unblock']));
    document.getElementById("updateBothButton")?.addEventListener("click", () => executeAction(tabId, ['apply_unveil', 'apply_unblock']));
    document.getElementById("revertButton")?.addEventListener("click", () => executeAction(tabId, ['revert_all']));
    localizeUI();
    await loadCheckboxState();
    await updateUI(tabId);
    setupCheckboxLogic();
}

function localizeUI() {
    document.querySelectorAll('[data-i18n-key]').forEach(element => {
        if (element.tagName === 'BUTTON') return;
        const message = chrome.i18n.getMessage(element.getAttribute('data-i18n-key'));
        if (message) {
            if (element.tagName === 'LABEL') {
                const existingText = Array.from(element.childNodes).find(node => node.nodeType === Node.TEXT_NODE);
                if (!existingText || !existingText.textContent.trim()) {
                    element.prepend(message + ' ');
                }
            } else {
                element.textContent = message;
            }
        }
    });
}

const areOptionsEqual = (opts1, opts2) => {
    if (!opts1 || !opts2) return false;
    return CHECKBOX_KEYS.filter(k => k !== 'persist_changes').every(key => !!opts1[key] === !!opts2[key]);
};

const getCurrentOptions = () => {
    const options = {};
    for (const key of CHECKBOX_KEYS) {
        options[key] = document.querySelector(`input[data-key="${key}"]`)?.checked ?? false;
    }
    return options;
};

function updateUI(tabId) {
    return new Promise(resolve => {
        chrome.scripting.executeScript({
            target: { tabId },
            func: () => {
                if (window.lazySecState && window.lazySecState.activeActionTypes instanceof Set) {
                    return { ...window.lazySecState, activeActionTypes: Array.from(window.lazySecState.activeActionTypes) };
                }
                return window.lazySecState;
            },
        }, (results) => {
            if (chrome.runtime.lastError || !results || !results[0] || !results[0].result) {
                pageState = { isActive: false, activeActionTypes: new Set(), lastUsedOptions: null };
            } else {
                 pageState = results[0].result;
            }
            renderButtons();
            resolve();
        });
    });
}

function renderButtons() {
    const activeActionTypes = new Set(pageState.activeActionTypes);
    const { isActive } = pageState;
    const unveilButton = document.getElementById("unveilButton");
    const unblockButton = document.getElementById("unblockButton");
    const updateBothButton = document.getElementById("updateBothButton");
    const revertButton = document.getElementById("revertButton");
    revertButton.style.display = isActive ? 'block' : 'none';
    revertButton.textContent = chrome.i18n.getMessage('buttonRevert');
    unveilButton.style.display = 'block';
    unblockButton.style.display = 'block';
    updateBothButton.style.display = 'none';
    unveilButton.classList.remove("active-unveil");
    if (activeActionTypes.has('unveil')) {
        unveilButton.textContent = chrome.i18n.getMessage('buttonUnveiled');
        unveilButton.classList.add("active-unveil");
    } else {
        unveilButton.textContent = chrome.i18n.getMessage('buttonUnveil');
    }
    unblockButton.classList.remove("active-unblock");
    if (activeActionTypes.has('unblock')) {
        unblockButton.textContent = chrome.i18n.getMessage('buttonUnblocked');
        unblockButton.classList.add("active-unblock");
    } else {
        unblockButton.textContent = chrome.i18n.getMessage('buttonUnblock');
    }
}

function setupCheckboxLogic() {
    const allCheckbox = document.querySelector('input[data-key="all"]');
    const otherCheckboxes = CHECKBOX_KEYS.filter(k => k !== 'all').map(k => document.querySelector(`input[data-key="${k}"]`));
    
    const onCheckboxChange = () => {
        if (!pageState.isActive) return;
        const currentOptions = getCurrentOptions();
        const unveilButton = document.getElementById('unveilButton');
        const unblockButton = document.getElementById('unblockButton');
        const updateBothButton = document.getElementById('updateBothButton');
        const activeActionTypes = new Set(pageState.activeActionTypes);
        const isUnveilActive = activeActionTypes.has('unveil');
        const isUnblockActive = activeActionTypes.has('unblock');
        if (areOptionsEqual(currentOptions, pageState.lastUsedOptions)) {
            renderButtons();
        } else {
            if (isUnveilActive && isUnblockActive) {
                unveilButton.style.display = 'none';
                unblockButton.style.display = 'none';
                updateBothButton.style.display = 'block';
                updateBothButton.textContent = chrome.i18n.getMessage('buttonUpdateSelections');
            } else {
                const updateText = chrome.i18n.getMessage('buttonUpdateSelection');
                if (isUnveilActive) {
                    unveilButton.textContent = updateText;
                    unveilButton.classList.remove("active-unveil");
                }
                if (isUnblockActive) {
                    unblockButton.textContent = updateText;
                    unblockButton.classList.remove("active-unblock");
                }
            }
        }
    };
    
    const mainCheckboxes = otherCheckboxes.filter(cb => cb.dataset.key !== 'persist_changes');
    allCheckbox.addEventListener('change', () => {
        mainCheckboxes.forEach(cb => cb.checked = allCheckbox.checked);
        saveCheckboxState();
        onCheckboxChange();
    });
    mainCheckboxes.forEach(cb => cb.addEventListener('change', () => {
        allCheckbox.checked = mainCheckboxes.every(mcb => mcb.checked);
        saveCheckboxState();
        onCheckboxChange();
    }));
    document.querySelector('input[data-key="persist_changes"]')?.addEventListener('change', saveCheckboxState);
}

async function executeAction(tabId, actionTypes) {
    const options = getCurrentOptions();
    const storageKey = `tab_${tabId}`;

    if (actionTypes.includes('revert_all')) {
        await chrome.storage.session.remove(storageKey);

        // --- NOVA LÓGICA AQUI ---
        // Encontra o checkbox de persistência e o desmarca
        const persistCheckbox = document.querySelector('input[data-key="persist_changes"]');
        if (persistCheckbox) {
            persistCheckbox.checked = false;
        }
        // Salva o novo estado dos checkboxes (com a opção de persistir desmarcada)
        saveCheckboxState();

    } else {
        if (options.persist_changes) {
            const data = await chrome.storage.session.get(storageKey);
            const existingSettings = data[storageKey] || { actions: [] };
            const combinedActions = Array.from(new Set([...existingSettings.actions, ...actionTypes]));
            const settingsToSave = { actions: combinedActions, options: options };
            await chrome.storage.session.set({ [storageKey]: settingsToSave });
        } else {
            await chrome.storage.session.remove(storageKey);
        }
    }
    
    await chrome.scripting.executeScript({
        target: { tabId },
        func: (actions, opts) => { window.lazySecActionType = actions; Object.assign(window, opts); },
        args: [actionTypes, options],
    });
    await chrome.scripting.executeScript({ target: { tabId }, files: ["lazysec-script.js"] });
    window.close();
}

function saveCheckboxState() {
    const currentState = getCurrentOptions();
    chrome.storage.local.set({ [STORAGE_KEY]: currentState });
}

function loadCheckboxState() {
    return new Promise(resolve => {
        chrome.storage.local.get([STORAGE_KEY], (result) => {
            const savedState = result[STORAGE_KEY];
            if (savedState) {
                for (const key of CHECKBOX_KEYS) {
                    const element = document.querySelector(`input[data-key="${key}"]`);
                    if (element) element.checked = savedState[key] || false;
                }
            }
            resolve();
        });
    });
}