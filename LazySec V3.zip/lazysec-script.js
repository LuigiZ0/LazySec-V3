// lazysec-script.js - v23.6 - Adiciona lógica de pluralização para as notificações

(function() {
  'use strict';
  // A trava de execução foi removida em versões anteriores.

  if (!window.lazySecState) {
    window.lazySecState = {
      elements: new Map(),
      isActive: false,
      activeActionTypes: new Set(),
      lastUsedOptions: null
    };
  }

  // --- NOVA FUNÇÃO DE NOTIFICAÇÃO "TOAST" ---
  function showToast(message) {
    const TOAST_CONTAINER_ID = 'lazysec-toast-container';
    let container = document.getElementById(TOAST_CONTAINER_ID);

    if (!container) {
      container = document.createElement('div');
      container.id = TOAST_CONTAINER_ID;
      Object.assign(container.style, {
        position: 'fixed', top: '20px', right: '20px', zIndex: '2147483647',
        display: 'flex', flexDirection: 'column', gap: '10px', alignItems: 'flex-end'
      });
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.textContent = message;
    Object.assign(toast.style, {
      backgroundColor: '#1a1a2e', color: '#e0e0e0', padding: '12px 20px', borderRadius: '5px',
      border: '2px solid #f038ff', fontFamily: 'Fira Code, monospace', fontSize: '14px',
      boxShadow: '0 4px 10px rgba(0,0,0,0.5)', opacity: '0', transform: 'translateX(100%)',
      transition: 'opacity 0.3s ease, transform 0.3s ease'
    });

    container.appendChild(toast);

    setTimeout(() => { toast.style.opacity = '1'; toast.style.transform = 'translateX(0)'; }, 10);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(100%)';
      setTimeout(() => {
        toast.remove();
        if (document.getElementById(TOAST_CONTAINER_ID)?.childElementCount === 0) {
          document.getElementById(TOAST_CONTAINER_ID)?.remove();
        }
      }, 300);
    }, 3000);
  }


  const getElementsToProcess = () => {
    const elements = new Set();
    if (window.all) {
      document.querySelectorAll('*').forEach(el => elements.add(el));
    } else {
      if (window.input_controls) document.querySelectorAll('input[type="radio"], input[type="text"], input[type="password"], input[type="checkbox"], textarea, select').forEach(el => elements.add(el));
      if (window.buttons) document.querySelectorAll('button, input[type=button], input[type=submit]').forEach(el => elements.add(el));
      if (window.divs) document.querySelectorAll('div').forEach(el => elements.add(el));
      if (window.labels) document.querySelectorAll('label, span, td, th, tr, p, h1, h2, h3, h4, a').forEach(el => elements.add(el));
    }
    return elements;
  };

  const saveOriginalState = (element) => {
    if (!window.lazySecState.elements.has(element)) {
      window.lazySecState.elements.set(element, {
        visibility: element.style.visibility, display: element.style.display, border: element.style.border,
        type: element.type, disabled: element.hasAttribute('disabled'), readonly: element.hasAttribute('readonly'),
        required: element.hasAttribute('required'), maxLength: element.getAttribute('maxLength'), pattern: element.getAttribute('pattern'),
      });
    }
  };

  const captureOptions = () => ({
      all: !!window.all, input_controls: !!window.input_controls, buttons: !!window.buttons,
      divs: !!window.divs, labels: !!window.labels,
  });

  function performUnveil() {
    const elements = getElementsToProcess();
    let modifiedCount = 0;
    elements.forEach(el => {
      let wasModified = false;
      if (el.style.visibility === "hidden" || el.style.display === "none" || el.type === "hidden") {
        saveOriginalState(el);
        if (el.style.visibility === "hidden") el.style.visibility = "visible";
        if (el.style.display === "none") el.style.display = "block";
        if (el.type === "hidden") el.type = "text";
        wasModified = true;
      }
      if (wasModified) { modifiedCount++; el.style.border = '2px solid #f038ff'; el.style.boxSizing = 'border-box'; }
    });
    if (modifiedCount > 0) window.lazySecState.activeActionTypes.add('unveil');
    return modifiedCount;
  }

  function performUnblock() {
    const elements = getElementsToProcess();
    let modifiedCount = 0;
    const attrsToRemove = ['readonly', 'required', 'maxLength', 'pattern'];
    elements.forEach(el => {
      let wasModified = false;
      if (el.hasAttribute('disabled') || attrsToRemove.some(attr => el.hasAttribute(attr)) || el.type === "email" || el.type === "url") {
        saveOriginalState(el);
        if (el.disabled) el.disabled = false;
        attrsToRemove.forEach(attr => el.removeAttribute(attr));
        if (el.type === "email" || el.type === "url") el.type = "text";
        wasModified = true;
      }
      if (wasModified) { modifiedCount++; el.style.border = '2px solid #ff4d4d'; el.style.boxSizing = 'border-box'; }
    });
    if (modifiedCount > 0) window.lazySecState.activeActionTypes.add('unblock');
    return modifiedCount;
  }
  
  function revertAllChanges() {
    window.lazySecState.elements.forEach((state, el) => {
        el.style.visibility = state.visibility; el.style.display = state.display; el.style.border = state.border;
        if (el.tagName.toLowerCase() === 'input' && state.type) el.type = state.type;
        if (state.disabled) el.setAttribute('disabled', ''); if (state.readonly) el.setAttribute('readonly', '');
        if (state.required) el.setAttribute('required', ''); if (state.maxLength) el.setAttribute('maxLength', state.maxLength);
        if (state.pattern) el.setAttribute('pattern', state.pattern);
    });
    
    window.lazySecState.elements.clear(); window.lazySecState.isActive = false;
    window.lazySecState.activeActionTypes.clear(); window.lazySecState.lastUsedOptions = null;
    
    chrome.runtime.sendMessage({ action: 'getTranslation', key: 'revertAll' }, r => { if (r?.message) showToast(r.message); });
  }

  let actions = window.lazySecActionType;
  if (!Array.isArray(actions)) {
    actions = [actions];
  }

  let unveilCount = 0;
  let unblockCount = 0;

  if (actions.includes('apply_unveil')) unveilCount = performUnveil();
  if (actions.includes('apply_unblock')) unblockCount = performUnblock();
  if (actions.includes('revert_all')) {
    revertAllChanges();
    return;
  }

  if (window.lazySecState.activeActionTypes.size > 0) {
      window.lazySecState.isActive = true;
      if (unveilCount > 0 || unblockCount > 0) {
          window.lazySecState.lastUsedOptions = captureOptions();
      }
  }
  
  // --- LÓGICA DE PLURALIZAÇÃO ATUALIZADA ---
  if (actions.includes('apply_unveil')) {
    if (unveilCount > 0) {
      const key = (unveilCount === 1) ? 'unveilAlert_singular' : 'unveilAlert_plural';
      chrome.runtime.sendMessage({ action: 'getTranslation', key: key, substitutions: [unveilCount] }, r => { if (r?.message) showToast(r.message); });
    } else {
      chrome.runtime.sendMessage({ action: 'getTranslation', key: 'unveilNone' }, r => { if (r?.message) showToast(r.message); });
    }
  }
  
  if (actions.includes('apply_unblock')) {
    setTimeout(() => {
        if (unblockCount > 0) {
            const key = (unblockCount === 1) ? 'unblockAlert_singular' : 'unblockAlert_plural';
            chrome.runtime.sendMessage({ action: 'getTranslation', key: key, substitutions: [unblockCount] }, r => { if (r?.message) showToast(r.message); });
        } else {
            chrome.runtime.sendMessage({ action: 'getTranslation', key: 'unblockNone' }, r => { if (r?.message) showToast(r.message); });
        }
    }, 50);
  }
})();